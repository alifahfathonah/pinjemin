Thanks for downloading this template!

Template Name: Pratt
Template URL: https://templatemag.com/pratt-app-landing-page-template/
Author: TemplateMag.com
License: https://templatemag.com/license/