<div class="row">
	<div class="col-md-12">
		<div class="au-card recent-report">
            <div class="au-card-inner">
            	<h4>Dashboard</h4>
				<hr/>
				<p>Selamat datang di halaman utama</p>
            </div>
        </div>
		
	</div>
</div>

